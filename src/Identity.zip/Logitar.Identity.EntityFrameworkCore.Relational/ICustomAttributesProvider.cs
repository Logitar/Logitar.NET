﻿namespace Logitar.Identity.EntityFrameworkCore.Relational;

public interface ICustomAttributesProvider
{
  string? CustomAttributes { get; }
}
