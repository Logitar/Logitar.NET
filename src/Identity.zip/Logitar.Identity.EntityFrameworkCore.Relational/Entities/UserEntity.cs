﻿using Logitar.Identity.Domain;
using Logitar.Identity.Domain.Users.Events;
using Logitar.Identity.EntityFrameworkCore.Relational.Actors;
using Logitar.Identity.EntityFrameworkCore.Relational.Constants;

namespace Logitar.Identity.EntityFrameworkCore.Relational.Entities;

public record UserEntity : AggregateEntity, ICustomAttributesProvider
{
  public UserEntity(UserCreatedEvent created, ActorEntity actor) : base(created, actor)
  {
    TenantId = created.TenantId;

    UniqueName = created.UniqueName;
  }

  private UserEntity() : base()
  {
  }

  public int UserId { get; private set; }

  public string? TenantId { get; private set; }

  public string UniqueName { get; private set; } = string.Empty;
  public string UniqueNameNormalized
  {
    get => UniqueName.ToUpper();
    private set { }
  }

  public string? Password { get; private set; }
  public bool HasPassword
  {
    get => Password != null;
    private set { }
  }
  public string? PasswordChangedById { get; private set; }
  public string? PasswordChangedBy { get; private set; }
  public DateTime? PasswordChangedOn { get; private set; }

  public string? DisabledById { get; private set; }
  public string? DisabledBy { get; private set; }
  public DateTime? DisabledOn { get; private set; }
  public bool IsDisabled { get; private set; }

  public string? AddressStreet { get; private set; }
  public string? AddressLocality { get; private set; }
  public string? AddressCountry { get; private set; }
  public string? AddressRegion { get; private set; }
  public string? AddressPostalCode { get; private set; }
  public string? AddressFormatted { get; private set; }
  public string? AddressVerifiedById { get; private set; }
  public string? AddressVerifiedBy { get; private set; }
  public DateTime? AddressVerifiedOn { get; private set; }
  public bool IsAddressVerified { get; private set; }

  public string? EmailAddress { get; private set; }
  public string? EmailAddressNormalized
  {
    get => EmailAddress?.ToUpper();
    private set { }
  }
  public string? EmailVerifiedById { get; private set; }
  public string? EmailVerifiedBy { get; private set; }
  public DateTime? EmailVerifiedOn { get; private set; }
  public bool IsEmailVerified { get; private set; }

  public string? PhoneCountryCode { get; private set; }
  public string? PhoneNumber { get; private set; }
  public string? PhoneExtension { get; private set; }
  public string? PhoneE164Formatted { get; private set; }
  public string? PhoneVerifiedById { get; private set; }
  public string? PhoneVerifiedBy { get; private set; }
  public DateTime? PhoneVerifiedOn { get; private set; }
  public bool IsPhoneVerified { get; private set; }

  public bool IsConfirmed
  {
    get => IsAddressVerified || IsEmailVerified || IsPhoneVerified;
    private set { }
  }

  public DateTime? AuthenticatedOn { get; private set; }

  public string? FirstName { get; private set; }
  public string? MiddleName { get; private set; }
  public string? LastName { get; private set; }
  public string? FullName { get; private set; }
  public string? Nickname { get; private set; }

  public DateTime? Birthdate { get; private set; }
  public string? Gender { get; private set; }
  public string? Locale { get; private set; }
  public string? TimeZone { get; private set; }

  public string? Profile { get; private set; }
  public string? Picture { get; private set; }
  public string? Website { get; private set; }

  public string? CustomAttributes { get; private set; }

  public List<ExternalIdentifierEntity> ExternalIdentifiers { get; private set; } = new();
  public List<RoleEntity> Roles { get; private set; } = new();
  public List<SessionEntity> Sessions { get; private set; } = new();

  public void Authenticate(UserAuthenticatedEvent authenticated)
  {
    SetVersion(authenticated);

    AuthenticatedOn = authenticated.OccurredOn.ToUniversalTime();
  }

  public void ChangePassword(UserPasswordChangedEvent change, ActorEntity actor)
  {
    SetVersion(change);

    Password = change.Password.Encode();
    PasswordChangedById = change.ActorId ?? Actor.DefaultId;
    PasswordChangedBy = actor.Serialize();
    PasswordChangedOn = change.OccurredOn.ToUniversalTime();
  }

  public void Disable(UserDisabledEvent disabled, ActorEntity actor)
  {
    SetVersion(disabled);

    DisabledById = disabled.ActorId;
    DisabledBy = actor.Serialize();
    DisabledOn = disabled.OccurredOn.ToUniversalTime();
    IsDisabled = true;
  }

  public void Enable(UserEnabledEvent enabled, ActorEntity actor)
  {
    Update(enabled, actor);

    DisabledById = null;
    DisabledBy = null;
    DisabledOn = null;
    IsDisabled = false;
  }

  public void ResetPassword(UserPasswordResetEvent change, ActorEntity actor)
  {
    SetVersion(change);

    Password = change.Password.Encode();
    PasswordChangedById = change.ActorId ?? Actor.DefaultId;
    PasswordChangedBy = actor.Serialize();
    PasswordChangedOn = change.OccurredOn.ToUniversalTime();
  }

  public override void SetActor(string id, string json)
  {
    base.SetActor(id, json);

    if (PasswordChangedById == id)
    {
      PasswordChangedBy = json;
    }

    if (DisabledById == id)
    {
      DisabledBy = json;
    }

    if (AddressVerifiedById == id)
    {
      AddressVerifiedBy = json;
    }

    if (EmailVerifiedById == id)
    {
      EmailVerifiedBy = json;
    }

    if (PhoneVerifiedById == id)
    {
      PhoneVerifiedBy = json;
    }
  }

  public void SignIn(UserSignedInEvent signedIn)
  {
    SetVersion(signedIn);

    AuthenticatedOn = signedIn.OccurredOn.ToUniversalTime();
  }

  public void Update(UserUpdatedEvent updated, ActorEntity actor, IEnumerable<RoleEntity> roles)
  {
    Update(updated, actor);

    if (updated.UniqueName != null)
    {
      UniqueName = updated.UniqueName;
    }
    if (updated.Password != null)
    {
      Password = updated.Password.Encode();
      PasswordChangedById = updated.ActorId ?? Actor.DefaultId;
      PasswordChangedBy = actor.Serialize();
      PasswordChangedOn = updated.OccurredOn.ToUniversalTime();
    }

    if (updated.Address != null)
    {
      AddressStreet = updated.Address.Value?.Street;
      AddressLocality = updated.Address.Value?.Locality;
      AddressCountry = updated.Address.Value?.Country;
      AddressRegion = updated.Address.Value?.Region;
      AddressPostalCode = updated.Address.Value?.PostalCode;
      AddressFormatted = updated.Address.Value?.Format();

      if (updated.Address.Value == null || !updated.Address.Value.IsVerified)
      {
        AddressVerifiedById = null;
        AddressVerifiedBy = null;
        AddressVerifiedOn = null;
        IsAddressVerified = false;
      }
      else if (!IsAddressVerified && updated.Address.Value.IsVerified)
      {
        AddressVerifiedById = updated.ActorId ?? Actor.DefaultId;
        AddressVerifiedBy = actor.Serialize();
        AddressVerifiedOn = updated.OccurredOn.ToUniversalTime();
        IsAddressVerified = true;
      }
    }
    if (updated.Email != null)
    {
      EmailAddress = updated.Email.Value?.Address;

      if (updated.Email.Value == null || !updated.Email.Value.IsVerified)
      {
        EmailVerifiedById = null;
        EmailVerifiedBy = null;
        EmailVerifiedOn = null;
        IsEmailVerified = false;
      }
      else if (!IsEmailVerified && updated.Email.Value.IsVerified)
      {
        EmailVerifiedById = updated.ActorId ?? Actor.DefaultId;
        EmailVerifiedBy = actor.Serialize();
        EmailVerifiedOn = updated.OccurredOn.ToUniversalTime();
        IsEmailVerified = true;
      }
    }
    if (updated.Phone != null)
    {
      PhoneCountryCode = updated.Phone.Value?.CountryCode;
      PhoneNumber = updated.Phone.Value?.Number;
      PhoneExtension = updated.Phone.Value?.Extension;
      PhoneE164Formatted = updated.Phone.Value?.FormatToE164();

      if (updated.Phone.Value == null || !updated.Phone.Value.IsVerified)
      {
        PhoneVerifiedById = null;
        PhoneVerifiedBy = null;
        PhoneVerifiedOn = null;
        IsPhoneVerified = false;
      }
      else if (!IsPhoneVerified && updated.Phone.Value.IsVerified)
      {
        PhoneVerifiedById = updated.ActorId ?? Actor.DefaultId;
        PhoneVerifiedBy = actor.Serialize();
        PhoneVerifiedOn = updated.OccurredOn.ToUniversalTime();
        IsPhoneVerified = true;
      }
    }

    if (updated.FirstName != null)
    {
      FirstName = updated.FirstName.Value;
    }
    if (updated.MiddleName != null)
    {
      MiddleName = updated.MiddleName.Value;
    }
    if (updated.LastName != null)
    {
      LastName = updated.LastName.Value;
    }
    if (updated.FullName != null)
    {
      FullName = updated.FullName.Value;
    }
    if (updated.Nickname != null)
    {
      Nickname = updated.Nickname.Value;
    }

    if (updated.Birthdate != null)
    {
      Birthdate = updated.Birthdate.Value?.ToUniversalTime();
    }
    if (updated.Gender != null)
    {
      Gender = updated.Gender.Value?.Value;
    }
    if (updated.Locale != null)
    {
      Locale = updated.Locale.Value?.Name;
    }
    if (updated.TimeZone != null)
    {
      TimeZone = updated.TimeZone.Value?.Id;
    }

    if (updated.Picture != null)
    {
      Picture = updated.Picture.Value?.ToString();
    }
    if (updated.Profile != null)
    {
      Profile = updated.Profile.Value?.ToString();
    }
    if (updated.Website != null)
    {
      Website = updated.Website.Value?.ToString();
    }

    CustomAttributes = this.UpdateCustomAttributes(updated.CustomAttributes);

    Dictionary<string, ExternalIdentifierEntity> externalIdentifiers = ExternalIdentifiers.ToDictionary(x => x.Key, x => x);
    foreach (var (key, value) in updated.ExternalIdentifiers)
    {
      _ = externalIdentifiers.TryGetValue(key, out ExternalIdentifierEntity? externalIdentifier);

      if (value == null)
      {
        if (externalIdentifier != null)
        {
          ExternalIdentifiers.Remove(externalIdentifier);
        }
      }
      else if (externalIdentifier == null)
      {
        externalIdentifier = new(updated, actor, this, key, value);
        ExternalIdentifiers.Add(externalIdentifier);
      }
      else
      {
        externalIdentifier.Update(updated, actor, value);
      }
    }

    Dictionary<string, RoleEntity> rolesById = roles.ToDictionary(x => x.AggregateId, x => x);
    foreach (var (roleId, action) in updated.Roles)
    {
      RoleEntity role = rolesById[roleId];

      switch (action)
      {
        case CollectionAction.Add:
          Roles.Add(role);
          break;
        case CollectionAction.Remove:
          Roles.Remove(role);
          break;
      }
    }
  }
}
