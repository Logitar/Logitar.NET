﻿namespace Logitar.Identity.Core.Payloads;

public enum SearchOperator
{
  And = 0,
  Or = 1
}
