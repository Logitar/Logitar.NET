﻿namespace Logitar.Identity.Core.Sessions.Payloads;

public enum SessionSort
{
  SignedOutOn,
  UpdatedOn
}
