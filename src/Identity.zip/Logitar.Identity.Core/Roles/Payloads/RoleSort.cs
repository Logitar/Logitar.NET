﻿namespace Logitar.Identity.Core.Roles.Payloads;

public enum RoleSort
{
  DisplayName,
  UniqueName,
  UpdatedOn
}
