﻿namespace Logitar.Identity.Core.ApiKeys.Payloads;

public enum ApiKeySort
{
  ExpiresOn,
  Title,
  UpdatedOn
}
