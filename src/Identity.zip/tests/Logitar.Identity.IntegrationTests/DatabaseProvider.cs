﻿namespace Logitar.Identity.IntegrationTests;

public enum DatabaseProvider
{
  EntityFrameworkCorePostgreSQL,
  EntityFrameworkCoreSqlServer
}
