﻿namespace Logitar.Identity.Domain.Users;

public interface IEmailAddress
{
  string Address { get; }
}
