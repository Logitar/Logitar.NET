﻿namespace Logitar.Identity.Domain;

public enum CollectionAction
{
  Add,
  Remove
}
