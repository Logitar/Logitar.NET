﻿namespace Logitar.Identity.Domain.Settings;

public interface IUniqueNameSettings
{
  string? AllowedCharacters { get; }
}
