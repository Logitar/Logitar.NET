﻿namespace Logitar.Identity.Domain.Settings;

public interface IRoleSettings
{
  IUniqueNameSettings UniqueNameSettings { get; }
}
